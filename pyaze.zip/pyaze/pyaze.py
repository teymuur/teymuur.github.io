#SPDX-License: MIT
#Author: Teymur babayev




def yaz(*dat):
    dat = ''.join(map(str, dat))
    print(str(dat))

def oxu(ask = ""):
    dat = input(ask)
    return dat   
def əgər(cond,funk, yoxsa = None):
    if (cond):
        exec(funk)
    elif yoxsa != None:
        exec(yoxsa)

def nəqədərki(cond,funk):
    while cond:
        exec(funk)

def dogru():
    return True
def yanlis():
        return False

def kömək():
    yaz('''Bu funksiya sizə bu modul haqqında məlumat vermək üçündü
        Bu modulun içindəki funksiyalar haqqında daha çox məlumat almaq üçün https://pypi.org/project/pyaze
        By sayda deyilən funsiyaları işlətmək üçün axırlarına () qoyun
        məsələn: yaz('Salam')
        Burada 'Salam' arqumentdi və yaz funksiyadı
        Bəzi funksiyalarda arqument boş qalam bilər(məsələn: oxu() funksiyası istifadəçinin yazdığını oxumaq üçündü) vəya birdən çox arqument(məsələn: ) ola bilər''')
def təyin(arg,b):
   global təyinolunmuş
   təyinolunmuş = {
       arg:b
   }
def cəm(a,b):
    return sum(a,b)
def ədəd(dat):
    return int(dat)
def sətir(dat):
    return str(dat)