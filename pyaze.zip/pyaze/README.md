
Bu python modulu python-un içindəki funksiyaları Azərbaycan dilinə çevirir və İngilis dilini bilməyənlər və python-u yeni öyrənənlər üçün asandlaşdırır.
Bu modulun kodu MİT lisenziyası altındadır
Daha çox məlumat üçün kömək() funsiyasını istidə edin
Versiya:1ş2
---------------------------------------------------------------------------------------------------------------------------------------------------

This python module translates the functions inside python into Azerbaijani and makes it easier to learn python for people who doesn't speak english.
This module is under MIT license
