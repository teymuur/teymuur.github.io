from pyaze import *
yaz("Salam. Neçə yaşın var?")
ans = ədəd(oxu())
yaz("5 il sonra "+sətir(ans+5)+" yaşın olacaq")