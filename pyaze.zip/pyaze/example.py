from pyaze import *
yaz("Salam")
ans = ədəd(oxu("neçə yaş"))
təyin('a',ans)
əgər(ans == 14,'print("Yaşıdıq")',yoxsa='print(təyinolunmuş["a"],"yaşın var")')